module.exports = {
    'transpileDependencies': [
        'vuetify'
    ]
}
