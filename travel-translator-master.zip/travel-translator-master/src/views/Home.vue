<template>
  <div class="home">
    <Translator />
  </div>
</template>

<script>
import Translator from "@/components/Translator.vue";

export default {
  name: "home",
  components: {
    Translator
  }
};
</script>
