<template>
  <div>
    <router-link to="/">
      <v-btn class="mx-0 mb-4" fab dark x-small color="primary">
        <v-icon dark>arrow_back</v-icon>
      </v-btn>
    </router-link>
    <h1 class="mb-8">Terms of Use</h1>
    <div>
      <p>By using this "Travel Translator" demo web application (website) you are agreeing to be bound by the following terms and conditions ("Terms of Use"). These terms and conditions are under the laws of Belgium. In case of any court trial, the place for court shall be Brussels, Belgium. In the following, we may also refer to the operator of the "Travel Translator" demo web application as "we," "us" or "our".</p>
      <h2>Terms</h2>
      <p>All content, which can be uploaded and shared through the "Travel Translator" demo web application will be described as "content" in the following terms and comprises all kinds of photos, designs, sketches, scans, texts, comments and other digital media.</p>
      <p></p>
      <ul>
        <li>You must not upload, post, share, annotate any content protected by copyright or other intellectual property rights without the prior approval of the copyright owner.</li>
        <li>You are solely responsible for your content that you submit, post, and display on the "Travel Translator" demo web application.</li>
        <li>You must not upload, post, share any content, which shows/describes illegal, offensive, defamatory, obscene, threatening, libelous, or otherwise objectionable material (e. g. violence, pornography, drugs).</li>
        <li>You must not use the "Travel Translator" demo web application or its affiliated websites for any illegal or unauthorized purpose. You agree to comply with all local laws regarding online conduct and acceptable content.</li>
        <li>You are responsible for any activity that occurs under your name.</li>
        <li>You must not abuse, harass, threaten, impersonate or intimidate other "Travel Translator" demo web application users.</li>
        <li>You must not transmit any dangerous computer code like worms or viruses through the "Travel Translator" demo web application.</li>
        <li>You must not, in the use of the "Travel Translator" demo web application, violate any laws in your jurisdiction (including but not limited to copyright laws).</li>
      </ul>
      <p></p>
      <p>While we prohibits such conduct and content on this demo web application, you understand and agree that we cannot be responsible for the content posted on this demo web application and you nonetheless may be exposed to such materials and that you use the "Travel Translator" demo web application at your own risk.</p>
      <h2>Conditions</h2>
      <p></p>
      <ul>
        <li>We reserve the right to modify or terminate the "Travel Translator" demo web application for any reason, without notice at any time.</li>
        <li>You must not use the "Travel Translator" demo web application for diagnostic or therapeutic patient use or for translation of any instructions/directions for use of any medicine or medical treatment. The translations tools used by the "Travel Translator" demo web application may contain errors and display wrong translation.</li>
        <li>We reserve the right to alter these Terms of Use at any time, without notice.</li>
        <li>We reserve the right to remove any content, which we consider as unlawful, offensive, threatening, libelous, defamatory, obscene or otherwise objectionable or violates any party's intellectual property or these Terms of Use.</li>
        <li>We provide our website and services on an “as is” and “as available” basis. WE DO NOT MAKE ANY WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY (INCLUDING BUT NOT LIMITED TO FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT) REGARDING THE USE OR THE RESULTS OF THE USE OF the "Travel Translator" demo web application OR ANY THIRD PARTY CONTENT, TO THE GREATEST EXTENT PERMITTED BY LAW.</li>
        <li>IN NO EVENT SHALL WE, OUR SUBSIDIARIES, OFFICERS, DIRECTORS, EMPLOYEES OR OUR SUPPLIERS BE LIABLE FOR ANY LOSS OF DAMAGE, INCLUDING BUT NOT LIMITED TO LOST PROFITS AND ANY SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF OR IN CONNECTION WITH OUR SITE, OUR SERVICES OR THESE TERMS OF USE (HOWEVER ARISING, INCLUDING NEGLIGENCE), TO THE GREATEST EXTENT PERMITTED BY LAW.</li>
        <li>You agree to indemnify and hold the operators of the "Travel Translator" demo web application (and our directors, employees or partners) harmless from any claim or demand, including reasonable attorneys' fees, made by any third party due to or arising out of your breach of these Terms of Use or the documents it incorporates by reference, or your violation of any law or the rights of a third party.</li>
        <li>In case of a court trial, the location of court trial is exlusively in Brussels, Belgium.</li>
      </ul>
      <p></p>
      <h2>Intellectual property rights</h2>
      <p></p>
      <ul>
        <li>The "Travel Translator" demo web application does NOT claim ANY ownership rights in the content that you upload / post / write on or through the "Travel Translator" demo web application. By uploading any content on or through the "Travel Translator" demo web application, you hereby grant to the "Travel Translator" demo web application owner a non-exclusive, fully paid and royalty-free, worldwide, limited license to use, modify, delete from, add to, publicly perform, publicly display, reproduce and translate such content, including without limitation distributing part or all of the website in any media formats through any media channels.</li>
        <li>You represent and warrant that: (i) you own the content posted by you on or through the "Travel Translator" demo web application or otherwise have the right to grant the license set forth in this section, (ii) the posting and use of your content on or through the "Travel Translator" demo web application does not violate the privacy rights, publicity rights, copyrights, contract rights, intellectual property rights or any other rights of any person, and (iii) the posting of your content on the "Travel Translator" demo web application does not result in a breach of contract between you and a third party. You agree to pay for all royalties, fees, and any other monies owing any person by reason of content you post on or through the "Travel Translator" demo web application.</li>
        <li>The "Travel Translator" demo web application is normally available. However, it may be that for scheduled maintenance or upgrades, for emergency repairs, or due to failure of telecommunications links and equipment that are beyond our control the "Travel Translator" demo web application and its services may have downtimes (go offline). Also, although the "Travel Translator" demo web application will normally only delete content that violates this agreement, the "Travel Translator" demo web application reserves the right to delete any content for any reason, without prior notice. Deleted content may be stored by the "Travel Translator" demo web application in order to comply with certain legal obligations and is not retrievable without a valid court order. Consequently, the "Travel Translator" demo web application encourages you to maintain your own backup of your content. In other words, the "Travel Translator" demo web application is not a backup service. The "Travel Translator" demo web application will not be liable to you for any modification, suspension, or discontinuation of the "Travel Translator" demo web application, or the loss of any content.</li>
        <li>To present your content, the "Travel Translator" demo web application digitally processes your content, which may change parts of your content.</li>
      </ul>
      <p></p>
      <h2>Machine learning</h2>
      <p>You agree that the "Travel Translator" demo web application automatically analyzes your uploaded images with Deep Learning / Machine Learning algorithms to execute the translation of its content. The analyses of your images are performed by 3rd party computers.</p>

      <router-link to="/">
        <v-btn class="mx-0 mb-4" fab dark x-small color="primary">
          <v-icon dark>arrow_back</v-icon>
        </v-btn>
      </router-link>
    </div>
  </div>
</template>
